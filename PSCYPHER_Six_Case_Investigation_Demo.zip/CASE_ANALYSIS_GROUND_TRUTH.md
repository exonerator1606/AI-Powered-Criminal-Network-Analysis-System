# PSCYPHER — Nandipur six-case investigation (synthetic)

## Scope and integrity
All people and incidents are fictional. FIRs are specimens modelled on the sections of the user-supplied BNSS Section 173 form; not actual police records.
Population: 10,000 citizens. Six missing/kidnapping report specimens. FIR-mentioned distinct people: 22. CDR rows: 1,300. Financial rows: 780.
Observed total unique named endpoints across imported records: 501. Every CDR and financial row includes at least one FIR-mentioned person.

## Six report timeline
- FIR 01: 12/09/2026 18:40; Diya Mishra reported missing from Tuition centre near Nandipur Bus Stand. Named for inquiry: Aarav Iyer, Rohan Mehta, Arjun Verma.
- FIR 02: 18/09/2026 19:25; Tara Jain reported missing from Transport Nagar service lane. Named for inquiry: Rohan Mehta, Vikram Singh, Kabir Khan.
- FIR 03: 24/09/2026 17:50; Riya Kapoor reported missing from Industrial Area bus stop. Named for inquiry: Aarav Iyer, Vikram Singh, Kavya Rao.
- FIR 04: 29/09/2026 20:10; Zoya Sheikh reported missing from Old Market / Railway Road. Named for inquiry: Rohan Mehta, Sahil Gupta, Farhan Ansari.
- FIR 05: 04/10/2026 18:20; Lakshmi Pillai reported missing from Civil Lines coaching junction. Named for inquiry: Aarav Iyer, Kabir Khan, Imran Qureshi.
- FIR 06: 08/10/2026 19:05; Yash Malhotra reported missing from NH-46 service road / Depot Gate. Named for inquiry: Vikram Singh, Rohan Mehta, Sanjay Patel.

## Measured network features in the generated evidence
Highest CDR participation (one participation per call, regardless of direction):
- Kabir Khan: 257 call observations; 145 financial-record participations
- Rohan Mehta: 250 call observations; 151 financial-record participations
- Aarav Iyer: 250 call observations; 160 financial-record participations
- Vikram Singh: 207 call observations; 158 financial-record participations
- Kavya Rao: 97 call observations; 39 financial-record participations
- Sanjay Patel: 95 call observations; 50 financial-record participations
- Sahil Gupta: 92 call observations; 60 financial-record participations
- Arjun Verma: 88 call observations; 61 financial-record participations
- Farhan Ansari: 75 call observations; 52 financial-record participations
- Imran Qureshi: 71 call observations; 55 financial-record participations
The following numbers are synthetic and refer to dataset frequencies, not proof of criminal conduct:
- Around case 1 occurrence (±12 hours): 157 town-scope generated CDR observations and 48 financial observations. This is a broad overlap, not individual-level causality.
- Around case 2 occurrence (±12 hours): 145 town-scope generated CDR observations and 60 financial observations. This is a broad overlap, not individual-level causality.
- Around case 3 occurrence (±12 hours): 151 town-scope generated CDR observations and 65 financial observations. This is a broad overlap, not individual-level causality.
- Around case 4 occurrence (±12 hours): 146 town-scope generated CDR observations and 50 financial observations. This is a broad overlap, not individual-level causality.
- Around case 5 occurrence (±12 hours): 150 town-scope generated CDR observations and 59 financial observations. This is a broad overlap, not individual-level causality.
- Around case 6 occurrence (±12 hours): 152 town-scope generated CDR observations and 54 financial observations. This is a broad overlap, not individual-level causality.

## Evidence anchors to use in the video
- Calls: Aarav Iyer ↔ Rohan Mehta: 45 recorded CDR rows; financial rows for same unordered pair: 13.
- Calls: Kabir Khan ↔ Rohan Mehta: 38 recorded CDR rows; financial rows for same unordered pair: 12.
- Calls: Kabir Khan ↔ Vikram Singh: 36 recorded CDR rows; financial rows for same unordered pair: 23.
- Calls: Aarav Iyer ↔ Kabir Khan: 35 recorded CDR rows; financial rows for same unordered pair: 16.
- Calls: Aarav Iyer ↔ Vikram Singh: 25 recorded CDR rows; financial rows for same unordered pair: 17.
- Calls: Arjun Verma ↔ Rohan Mehta: 23 recorded CDR rows; financial rows for same unordered pair: 7.

## Defensible investigative finding
The six FIRs share some named persons for inquiry. CDR and financial datasets show recurring contacts and recorded transfers connecting some of these persons, including activity near the report dates. This establishes an evidence-based lead to seek corroborating material and expand interviews, not that any person committed an offence or that a trafficking network has been proven.
Potential next steps: check verified locations and independent CCTV; obtain and compare authorized original telecom and bank records; interview witnesses; verify whether payment purposes are legitimate; use date-scoped network comparisons. Neither tower location nor transfer-frequency data independently establishes physical presence or criminal purpose.

## Important prototype interpretation
Run FIR uploads first: initial graph should contain people and no FIR-created edges. Next import the two relationship CSVs. The complete graph may show many nodes; use Graph Focus Top 10/20 for presentation. The scoring heuristics and link prediction are exploratory, not calibrated probabilities of guilt. The financial schema intentionally omits amount, so no money totals can be claimed.
