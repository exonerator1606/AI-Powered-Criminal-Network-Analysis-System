# PSCYPHER — Three-person SIH demonstration script (approximately 7–9 minutes)

**Cast:** A = Investigating Officer; B = Technical Lead; C = Evidence Analyst / Narrator.  
**Narrative rule:** Each step answers a question; figures are from the included synthetic evidence, not Gemini-generated claims.

## 00:00–00:45 — What is the case?
**[Visual: titles for six FIR specimens; no graph yet.]**  
**A:** “Six young people have been reported missing in Nandipur between 12 September and 8 October 2026. These are fictional police-training reports. Our question is whether the cases share persons or communications worth investigating, not whether anyone is guilty.”  
**C:** “The reported last-seen locations differ. We must first identify the persons named in the FIRs and then check independently recorded evidence.”

## 00:45–01:20 — Population registry versus case graph
**[Visual: Town Database menu; 10,000 synthetic citizens stored; blank investigation graph.]**  
**B:** “Our permanent synthetic registry contains 10,000 citizens. That is not a suspect list. The active graph begins empty and only displays individuals encountered in the investigation.”  
**A:** “Can we start with source reports instead of building an entity list manually?”

## 01:20–02:20 — Six FIR uploads
**[Visual: upload FIR_01 through FIR_06; confirm exact name matches. Hide inspector if graph area is small.]**  
**B:** “The text-based FIR specimens are extracted locally and their names are checked against the registry. Duplicate mentions reuse existing citizen IDs. No FIR node or FIR relationship edge is created: a report mention is not evidence of a call or money transfer.”  
**C:** “Observe that 22 distinct named persons recur across the six reports. We now have an initial investigation scope, not an accusation.”

## 02:20–03:20 — Calls establish observed links
**[Visual: import cdr_1300_FIR_SCOPED.csv. Use Graph Focus Top 20.]**  
**A:** “What connections can we substantiate?”  
**B:** “We import 1,300 call observations collected for the FIR-mentioned people. Every row includes one of them. The importer adds new call counterparts as nodes and joins them with CDR edges. Repeated calls are aggregated in the display.”  
**C:** “A tower location is a network observation, not proof that a person stood at a specific point. The graph offers a direction for verification.”

## 03:20–04:05 — Financial observations provide a second evidence layer
**[Visual: import financial_780_FIR_SCOPED.csv; select a relationship and inspect source row.]**  
**A:** “Do those same contacts occur in financial records?”  
**B:** “The second file contains 780 transfer observations, each also involving an FIR-mentioned person. Calls and financial transfers create different relationship types.”  
**C:** “Our financial CSV contains sender and recipient only, not amounts or purposes. We can discuss frequency and overlap, not quantify money or assign an illegal purpose.”

## 04:05–05:10 — Centrality, communities, and anomaly investigation
**[Visual: Analysis → Calculate Centrality; Graph Focus Top 10/Top 20; detect communities; Find Anomalies.]**  
**B:** “Degree tells us who connects to many nodes. Betweenness suggests possible bridges. Community analysis groups dense subnetworks. Anomalies flag unusual connectivity or observation patterns.”  
**A:** “We focus on evidence-rich intersections, not simply the largest circle. A busy transport operator may have entirely legitimate contacts.”  
**C:** “We look for convergence: repeated FIR mentions, distinct CDR and financial links, and chronology near the reported events. For instance, Aarav Iyer and Rohan Mehta appear together in 45 call rows and 13 financial rows (see the evidence reference sheet). We must still check their legitimate business explanations.”

## 05:10–06:00 — Link prediction: a question, not proof
**[Visual: Run Link Prediction; display candidate edges and ROC-AUC / average precision if available.]**  
**B:** “Our multi-layer link-prediction feature ranks pairs that could share an unobserved relationship based on network topology. Model metrics describe evaluation of that particular link-prediction approach.”  
**A:** “We do not convert predictions into facts. We ask what lawful source would confirm or reject the proposed link.”

## 06:00–07:25 — FIR-aware AI Copilot and evidence evaluator
**[Visual: select Rohan Mehta or Aarav Iyer, click Explain Score; read Scores, Analyst Gist, Hypothesis. Suggested Questions beneath response.]**  
**A:** “How do these six statements compare with the observed communication and transfer data?”  
**B:** “The Copilot gets constrained extracts of the FIR narratives plus graph metrics and records. It distinguishes the report's allegations from observed CDR and financial entries.”  
**C:** “We are looking for a testable hypothesis. For example: do the recurring contacts around these six events reflect ordinary logistics business, or coordination relevant to the missing-person cases? Both possibilities remain open.”  
**[Visual: click a contextual Suggested Question, or ask: ‘Which FIR passages and specific CDR/financial source rows jointly support the strongest cross-case lead, and what contradicts it?’]**

## 07:25–08:10 — Satisfactory conclusion and next investigation
**[Visual: Top 10 graph and a short conclusion slide.]**  
**A:** “We have narrowed a town of 10,000 citizens into an evidence-linked case graph, identified repeated names and independently recorded contacts, and prioritized relationships for verification.”  
**C:** “We have sufficient leads to request original records, CCTV, witness interviews and independent timeline checks. We have not proved kidnapping by these people or a trafficking syndicate.”  
**B:** “PSCYPHER turns fragmented records into an auditable, evolving investigative hypothesis while keeping decisions with the investigator.”

## Production notes
- Rehearse FIR uploads using the updated nodes-only importer. Use locally extractable PDFs; no live Gemini OCR is necessary for these text FIR specimens.
- Check that the actual graph ranking and AI output agree with the loaded data. Do not claim Gemini independently corroborated a source without a supporting row.
- Record or edit out repeated Yes/No identity confirmations for pacing, but do not imply they were fully automated if they were not.
- If link prediction returns insufficient training data for a layer, demonstrate the limitation rather than invent a result.
- Files and findings are all synthetic. Avoid the words “solved”, “arrested” or “trafficking confirmed”.
