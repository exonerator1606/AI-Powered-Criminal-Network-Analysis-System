# Evidence reference sheet — synthetic Nandipur case

Exact CSV line numbers include the header as row 1. Call and financial records below are generated observations; neither establishes a crime.

## Aarav Iyer ↔ Rohan Mehta
- Total CDRs: 45; financial rows: 13.
- Example CDR: row 4 — {'timestamp (DD/MM/YY HH:MM:SS)': '18/09/26 09:26:27', 'calling person': 'Rohan Mehta', 'called person': 'Aarav Iyer', 'duration': '237', 'tower-location': 'Depot Gate NH-46'}.
- Example financial: row 4 — {'timestamp (DD/MM/YY HH:MM:SS)': '04/10/26 18:55:11', 'Sender': 'Rohan Mehta', 'Recipient': 'Aarav Iyer'}.

## Rohan Mehta ↔ Vikram Singh
- Total CDRs: 22; financial rows: 24.
- Example CDR: row 126 — {'timestamp (DD/MM/YY HH:MM:SS)': '24/09/26 17:41:09', 'calling person': 'Vikram Singh', 'called person': 'Rohan Mehta', 'duration': '173', 'tower-location': 'Industrial Area'}.
- Example financial: row 5 — {'timestamp (DD/MM/YY HH:MM:SS)': '09/10/26 11:38:42', 'Sender': 'Vikram Singh', 'Recipient': 'Rohan Mehta'}.

## Kabir Khan ↔ Sanjay Patel
- Total CDRs: 18; financial rows: 11.
- Example CDR: row 52 — {'timestamp (DD/MM/YY HH:MM:SS)': '13/09/26 03:57:47', 'calling person': 'Kabir Khan', 'called person': 'Sanjay Patel', 'duration': '125', 'tower-location': 'Nandipur Bus Stand'}.
- Example financial: row 275 — {'timestamp (DD/MM/YY HH:MM:SS)': '24/09/26 16:32:28', 'Sender': 'Kabir Khan', 'Recipient': 'Sanjay Patel'}.
